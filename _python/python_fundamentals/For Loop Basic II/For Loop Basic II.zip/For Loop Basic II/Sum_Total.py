def total_sum(lst):
    return sum(lst)

print(total_sum([7,2,7,1]))