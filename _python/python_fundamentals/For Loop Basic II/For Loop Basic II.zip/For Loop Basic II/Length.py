def length(lst):
    count=0
    for i in lst:
        count += 1
    
    return count    

print(length([1,2,3,4,5,6]))
print(length([]))