# Print all integers from 0 to 150

# for x in range(0,151,1):
#     print(x)


#Multiples of Five 
# for y in range(5,1000,5):
#     print(y)


#    Counting, the Dojo Way
# for z in range(1,101,1):
    
#     if(z%10==0):
#         print("Coding Dojo")
        
#     elif (z%5==0):
#         print("Codeing")
    
#     else:
#         print(z)    


#  Add odd integers from 0 to 500,000
# sum =0
# for i in range(0,500000):
#     if(i%2!=0):
#         sum= sum+i

# print(sum)    


#Countdown by Fours
# for i in range(2018,0,-4):
#      print(i)
        
        
#Flexible Counter
lowNum=5
highNum=25
mult=5
for i in range(lowNum,highNum+1):
    if i% mult == 0:
        print(i)
        

    
    
        
        

  