def print_return(lst):
    print(lst[0])
    return(lst[1])

result= print_return([1,2])
print(result)    