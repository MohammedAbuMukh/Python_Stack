def sum(lst):
    first_val=(lst[0])
    last_val=(len(lst))
    return (first_val+ last_val)
    
    
result=sum([7,2,3,4,5,10])
print(result)