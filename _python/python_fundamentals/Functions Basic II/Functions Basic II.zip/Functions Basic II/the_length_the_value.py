def length_val(size,value):
    return [value] * size
    

result = length_val(4,7)
print(result)

