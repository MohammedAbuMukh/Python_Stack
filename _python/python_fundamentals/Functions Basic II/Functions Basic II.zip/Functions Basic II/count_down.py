def count_down(num):
    return [i for i in range(num,-1,-1)]

print(count_down(10))


    